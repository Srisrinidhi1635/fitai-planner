import { useState } from 'react'
import Login from './components/Login.jsx'
import ProfileSetup from './components/ProfileSetup.jsx'
import Dashboard from './components/Dashboard.jsx'
import DietPlan from './components/DietPlan.jsx'
import WorkoutPlan from './components/WorkoutPlan.jsx'
import Progress from './components/Progress.jsx'
import Leaderboard from './components/Leaderboard.jsx'
import Rewards from './components/Rewards.jsx'
import BottomNav from './components/BottomNav.jsx'

const defaultProfile = {
  name: '', age: '', weight: '', height: '',
  gender: 'male', goal: 'weight-loss',
  activity: 'sedentary', diet: 'balanced', allergies: ''
}

export default function App() {
  const [screen, setScreen] = useState('login')
  const [profile, setProfile] = useState(defaultProfile)

  const mainScreens = ['dashboard','diet','workout','progress','leaderboard','rewards']
  const showNav = mainScreens.includes(screen)

  const go = (s) => setScreen(s)

  return (
    <div style={{ display: 'flex', flexDirection: 'column', flex: 1, minHeight: '100vh' }}>
      <div style={{ flex: 1, overflowY: 'auto', paddingBottom: showNav ? 70 : 0 }}>
        {screen === 'login'       && <Login onLogin={() => go('setup')} />}
        {screen === 'setup'       && <ProfileSetup profile={profile} setProfile={setProfile} onDone={() => go('dashboard')} />}
        {screen === 'dashboard'   && <Dashboard profile={profile} go={go} />}
        {screen === 'diet'        && <DietPlan profile={profile} />}
        {screen === 'workout'     && <WorkoutPlan profile={profile} />}
        {screen === 'progress'    && <Progress />}
        {screen === 'leaderboard' && <Leaderboard profile={profile} />}
        {screen === 'rewards'     && <Rewards />}
      </div>
      {showNav && <BottomNav active={screen} go={go} />}
    </div>
  )
}
