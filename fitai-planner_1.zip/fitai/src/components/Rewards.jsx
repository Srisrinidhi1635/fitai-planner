const badges = [
  { icon: '🔥', label: '5-day streak', sub: 'Earned!', earned: true },
  { icon: '🏃', label: 'First workout', sub: 'Earned!', earned: true },
  { icon: '🥗', label: 'Clean eater',   sub: 'Earned!', earned: true },
  { icon: '🏆', label: '30-day streak', sub: '25 more days', earned: false },
  { icon: '💪', label: 'Iron will',     sub: '50 workouts',  earned: false },
  { icon: '⛰️', label: 'Peak form',     sub: 'Reach goal',   earned: false },
]

export default function Rewards() {
  return (
    <div>
      <div style={{ padding: '1.25rem', borderBottom: '1px solid #f0f0f0' }}>
        <h2 style={{ fontSize: 20, fontWeight: 600 }}>🎖️ Rewards</h2>
        <p style={{ fontSize: 13, color: '#888', marginTop: 3 }}>Earn badges by hitting your goals</p>
      </div>

      <div style={{ padding: '1rem 1.25rem' }}>
        {/* Coins banner */}
        <div style={{ background: 'linear-gradient(135deg,#BA7517,#EF9F27)', borderRadius: 16, padding: '1.25rem', color: '#fff', display: 'flex', alignItems: 'center', gap: 14, marginBottom: 20 }}>
          <div style={{ fontSize: 42 }}>🪙</div>
          <div>
            <div style={{ fontSize: 24, fontWeight: 700 }}>1,250 coins</div>
            <div style={{ fontSize: 13, opacity: 0.9 }}>Keep working out to earn more!</div>
          </div>
        </div>

        {/* Weekly streak */}
        <div style={{ background: '#EEEDFE', borderRadius: 14, padding: '1rem', marginBottom: 20 }}>
          <div style={{ fontSize: 14, fontWeight: 600, color: '#3C3489', marginBottom: 8 }}>🔥 Weekly streak — Day 5 of 7</div>
          <div style={{ display: 'flex', gap: 6 }}>
            {['M','T','W','T','F','S','S'].map((d, i) => (
              <div key={i} style={{ flex: 1, textAlign: 'center' }}>
                <div style={{ width: '100%', paddingBottom: '100%', borderRadius: '50%', background: i < 5 ? '#534AB7' : '#ddd', position: 'relative', marginBottom: 4 }}>
                  <span style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, color: i < 5 ? '#fff' : '#999' }}>✓</span>
                </div>
                <div style={{ fontSize: 10, color: '#888' }}>{d}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Badges */}
        <h3 style={sh}>Badges</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 10 }}>
          {badges.map(b => (
            <div key={b.label} style={{
              border: b.earned ? '1.5px solid #AFA9EC' : '1px solid #e5e7eb',
              background: b.earned ? '#EEEDFE' : '#fafafa',
              borderRadius: 14, padding: '14px 10px', textAlign: 'center',
              opacity: b.earned ? 1 : 0.65
            }}>
              <div style={{ fontSize: 28, marginBottom: 6 }}>{b.icon}</div>
              <div style={{ fontSize: 12, fontWeight: 600, color: b.earned ? '#3C3489' : '#555' }}>{b.label}</div>
              <div style={{ fontSize: 11, color: b.earned ? '#534AB7' : '#999', marginTop: 2 }}>{b.sub}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

const sh = { fontSize: 15, fontWeight: 600, color: '#1a1a2e', marginBottom: 12 }
