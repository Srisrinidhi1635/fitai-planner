import { useState } from 'react'

const API_KEY = import.meta.env.VITE_ANTHROPIC_API_KEY || ''

export async function callClaude(system, user) {
  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': API_KEY,
      'anthropic-version': '2023-06-01',
      'anthropic-dangerous-direct-browser-access': 'true',
    },
    body: JSON.stringify({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 1200,
      system,
      messages: [{ role: 'user', content: user }]
    })
  })
  const data = await res.json()
  if (data.error) throw new Error(data.error.message)
  return data.content[0].text
}

export default function DietPlan({ profile }) {
  const [extra, setExtra]       = useState('')
  const [result, setResult]     = useState('')
  const [loading, setLoading]   = useState(false)
  const [error, setError]       = useState('')

  const generate = async () => {
    setLoading(true); setError(''); setResult('')
    try {
      const system = `You are a professional nutritionist. Create practical, detailed meal plans.
Format with clear sections: Day, Meal (Breakfast/Lunch/Dinner/Snacks), Food items, Calories.
Be specific with portions. Keep it realistic and delicious.`
      const user = `Create a 3-day personalized meal plan.
Profile: ${profile.age}yr, ${profile.gender}, ${profile.weight}kg, ${profile.height}cm.
Goal: ${profile.goal.replace('-',' ')} | Activity: ${profile.activity} | Diet: ${profile.diet}.
${profile.allergies ? 'Allergies: '+profile.allergies+'.' : ''}
${extra ? 'Extra notes: '+extra : ''}
Show daily totals (calories, protein, carbs, fat).`
      const text = await callClaude(system, user)
      setResult(text)
    } catch(e) {
      setError('Could not connect to Claude AI. Check your API key in the .env file.')
    }
    setLoading(false)
  }

  return <PlanScreen
    icon="🥗" title="AI Diet Plan" color="#534AB7" bgColor="#EEEDFE"
    placeholder="e.g. I want high-protein meals, prefer Indian food, 7-day plan..."
    extra={extra} setExtra={setExtra}
    generate={generate} loading={loading} result={result} error={error}
    btnLabel="Generate my diet plan"
  />
}

export function PlanScreen({ icon, title, color, bgColor, placeholder, extra, setExtra, generate, loading, result, error, btnLabel }) {
  return (
    <div style={{ minHeight: '100%' }}>
      <div style={{ padding: '1.25rem', borderBottom: '1px solid #f0f0f0' }}>
        <h2 style={{ fontSize: 20, fontWeight: 600 }}>{icon} {title}</h2>
        <p style={{ fontSize: 13, color: '#888', marginTop: 3 }}>Powered by Claude AI</p>
      </div>

      <div style={{ padding: '1rem 1.25rem' }}>
        <div style={{ background: bgColor, borderRadius: 14, padding: '1rem', marginBottom: 16, border: `1px solid ${color}33` }}>
          <p style={{ fontSize: 13, color: color, fontWeight: 600, marginBottom: 8 }}>Customize your request (optional)</p>
          <textarea
            value={extra} onChange={e => setExtra(e.target.value)}
            placeholder={placeholder}
            rows={3}
            style={{ width: '100%', border: '1px solid #ddd', borderRadius: 10, padding: 10, fontSize: 14, resize: 'none', outline: 'none', color: '#222', background: '#fff' }}
          />
          <button
            onClick={generate} disabled={loading}
            style={{ width: '100%', padding: 12, background: loading ? '#a09ad4' : color, color: '#fff', border: 'none', borderRadius: 10, fontSize: 14, fontWeight: 600, cursor: loading ? 'not-allowed' : 'pointer', marginTop: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
            {loading ? '⏳ Generating...' : `✨ ${btnLabel}`}
          </button>
        </div>

        {error && (
          <div style={{ background: '#fff5f5', border: '1px solid #fecaca', borderRadius: 12, padding: '1rem', color: '#991b1b', fontSize: 14, marginBottom: 16 }}>
            ⚠️ {error}
          </div>
        )}

        {loading && (
          <div style={{ textAlign: 'center', padding: '2rem' }}>
            <div style={{ fontSize: 32, marginBottom: 8 }}>🤖</div>
            <p style={{ color: '#888', fontSize: 14 }}>Claude is thinking...</p>
          </div>
        )}

        {result && (
          <div style={{ background: '#fafafa', border: '1px solid #f0f0f0', borderRadius: 14, padding: '1rem', fontSize: 14, lineHeight: 1.8, whiteSpace: 'pre-wrap', color: '#222' }}>
            {result}
          </div>
        )}
      </div>
    </div>
  )
}
