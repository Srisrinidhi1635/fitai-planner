const tabs = [
  { id: 'dashboard',   label: 'Home',     icon: '🏠' },
  { id: 'diet',        label: 'Diet',     icon: '🥗' },
  { id: 'workout',     label: 'Workout',  icon: '🏋️' },
  { id: 'progress',    label: 'Progress', icon: '📊' },
  { id: 'leaderboard', label: 'Rank',     icon: '🏆' },
]

export default function BottomNav({ active, go }) {
  return (
    <nav style={{
      position: 'fixed', bottom: 0, left: '50%', transform: 'translateX(-50%)',
      width: '100%', maxWidth: 430,
      background: '#fff', borderTop: '1px solid #f0f0f0',
      display: 'flex', justifyContent: 'space-around',
      padding: '8px 0 14px', zIndex: 100
    }}>
      {tabs.map(t => (
        <button key={t.id} onClick={() => go(t.id)} style={{
          display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2,
          background: 'none', border: 'none', cursor: 'pointer',
          fontSize: 10, fontWeight: active === t.id ? 700 : 400,
          color: active === t.id ? '#534AB7' : '#999',
          padding: '4px 10px', fontFamily: 'inherit'
        }}>
          <span style={{ fontSize: 22 }}>{t.icon}</span>
          {t.label}
        </button>
      ))}
    </nav>
  )
}
