const metrics = [
  { icon: '🔥', label: 'Calories burned', cur: 3240, max: 4000, color: '#534AB7', bg: '#EEEDFE' },
  { icon: '🚶', label: 'Steps',            cur: 42800, max: 70000, color: '#1D9E75', bg: '#E1F5EE' },
  { icon: '💧', label: 'Water intake',     cur: 10.5, max: 14, color: '#EF9F27', bg: '#FAEEDA', suffix: 'L' },
  { icon: '🏋️', label: 'Workouts',         cur: 4, max: 5, color: '#D4537E', bg: '#FBEAF0', suffix: ' sessions' },
]

export default function Progress() {
  const overall = Math.round(metrics.reduce((a, m) => a + m.cur / m.max, 0) / metrics.length * 100)
  const r = 54, circ = 2 * Math.PI * r
  const offset = circ * (1 - overall / 100)

  return (
    <div>
      <div style={{ padding: '1.25rem', borderBottom: '1px solid #f0f0f0' }}>
        <h2 style={{ fontSize: 20, fontWeight: 600 }}>📊 Progress</h2>
        <p style={{ fontSize: 13, color: '#888', marginTop: 3 }}>Your weekly fitness journey</p>
      </div>

      <div style={{ padding: '1rem 1.25rem' }}>
        {/* Ring */}
        <div style={{ display: 'flex', justifyContent: 'center', margin: '0.5rem 0 1.5rem' }}>
          <svg width={140} height={140} viewBox="0 0 140 140">
            <circle cx={70} cy={70} r={r} fill="none" stroke="#f0f0f0" strokeWidth={14} />
            <circle cx={70} cy={70} r={r} fill="none" stroke="#534AB7" strokeWidth={14}
              strokeDasharray={circ} strokeDashoffset={offset}
              strokeLinecap="round" transform="rotate(-90 70 70)" />
            <text x={70} y={65} textAnchor="middle" fontSize={22} fontWeight={700} fill="#534AB7">{overall}%</text>
            <text x={70} y={82} textAnchor="middle" fontSize={12} fill="#888">weekly goal</text>
          </svg>
        </div>

        <h3 style={sh}>This week</h3>
        {metrics.map(m => {
          const pct = Math.round(m.cur / m.max * 100)
          return (
            <div key={m.label} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: 12, border: '1px solid #f0f0f0', borderRadius: 14, marginBottom: 10, background: '#fff' }}>
              <div style={{ width: 42, height: 42, borderRadius: '50%', background: m.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20, flexShrink: 0 }}>{m.icon}</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 14, fontWeight: 600, color: '#1a1a2e' }}>{m.label}</div>
                <div style={{ fontSize: 12, color: '#888', marginBottom: 5 }}>{m.cur.toLocaleString()}{m.suffix || ''} / {m.max.toLocaleString()}{m.suffix || ''}</div>
                <div style={{ background: '#f0f0f0', borderRadius: 4, height: 6, overflow: 'hidden' }}>
                  <div style={{ height: '100%', borderRadius: 4, background: m.color, width: `${pct}%` }} />
                </div>
              </div>
              <span style={{ fontSize: 15, fontWeight: 700, color: m.color, minWidth: 36, textAlign: 'right' }}>{pct}%</span>
            </div>
          )
        })}
      </div>
    </div>
  )
}

const sh = { fontSize: 15, fontWeight: 600, color: '#1a1a2e', marginBottom: 12 }
