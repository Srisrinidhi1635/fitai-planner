import { useState } from 'react'

const goals = [
  { val: 'weight-loss', label: 'Lose weight', icon: '📉' },
  { val: 'muscle-gain', label: 'Build muscle', icon: '💪' },
  { val: 'endurance',   label: 'Endurance',   icon: '🏃' },
  { val: 'maintain',    label: 'Stay healthy', icon: '❤️' },
]
const activities = [
  { val: 'sedentary', label: 'Sedentary', sub: 'desk job, little exercise' },
  { val: 'moderate',  label: 'Moderate',  sub: '3–4x/week exercise' },
  { val: 'active',    label: 'Active',    sub: 'daily workouts' },
]
const diets = [
  { val: 'balanced',    label: 'Balanced',    icon: '🥗' },
  { val: 'vegetarian',  label: 'Vegetarian',  icon: '🥦' },
  { val: 'vegan',       label: 'Vegan',       icon: '🌱' },
  { val: 'keto',        label: 'Keto',        icon: '🥩' },
]

export default function ProfileSetup({ profile, setProfile, onDone }) {
  const [step, setStep] = useState(1)
  const set = (key, val) => setProfile(p => ({ ...p, [key]: val }))

  const OptionCard = ({ selected, onClick, children }) => (
    <div onClick={onClick} style={{
      border: selected ? '2px solid #534AB7' : '1px solid #e5e7eb',
      background: selected ? '#EEEDFE' : '#fff',
      borderRadius: 12, padding: '12px 10px', cursor: 'pointer',
      textAlign: 'center', fontSize: 14, fontWeight: selected ? 600 : 400,
      color: selected ? '#3C3489' : '#333', transition: 'all 0.15s'
    }}>{children}</div>
  )

  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
      {/* Header */}
      <div style={{ background: '#EEEDFE', padding: '1.5rem 1.25rem 1rem', textAlign: 'center' }}>
        <h2 style={{ fontSize: 20, fontWeight: 600, color: '#3C3489' }}>Set up your profile</h2>
        <p style={{ fontSize: 13, color: '#534AB7', marginTop: 4 }}>Personalize your AI fitness plans</p>
        <div style={{ display: 'flex', justifyContent: 'center', gap: 6, marginTop: 12 }}>
          {[1,2,3].map(i => (
            <div key={i} style={{ height: 8, borderRadius: 4, background: i === step ? '#534AB7' : '#C5C2F0', width: i === step ? 24 : 8, transition: 'all 0.3s' }} />
          ))}
        </div>
      </div>

      <div style={{ padding: '1.5rem 1.25rem', flex: 1 }}>
        {/* Step 1: Basic info */}
        {step === 1 && <>
          <h3 style={sh}>Basic info</h3>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 16 }}>
            <div><label style={lbl}>Your name</label><input style={inp} placeholder="Alex" value={profile.name} onChange={e => set('name', e.target.value)} /></div>
            <div><label style={lbl}>Age</label><input style={inp} type="number" placeholder="25" value={profile.age} onChange={e => set('age', e.target.value)} /></div>
            <div><label style={lbl}>Weight (kg)</label><input style={inp} type="number" placeholder="70" value={profile.weight} onChange={e => set('weight', e.target.value)} /></div>
            <div><label style={lbl}>Height (cm)</label><input style={inp} type="number" placeholder="170" value={profile.height} onChange={e => set('height', e.target.value)} /></div>
          </div>
          <h3 style={sh}>Gender</h3>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 24 }}>
            <OptionCard selected={profile.gender==='male'} onClick={() => set('gender','male')}>👨 Male</OptionCard>
            <OptionCard selected={profile.gender==='female'} onClick={() => set('gender','female')}>👩 Female</OptionCard>
          </div>
          <button style={btnP} onClick={() => setStep(2)}>Continue →</button>
        </>}

        {/* Step 2: Goal + activity */}
        {step === 2 && <>
          <h3 style={sh}>Your goal</h3>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 20 }}>
            {goals.map(g => (
              <OptionCard key={g.val} selected={profile.goal===g.val} onClick={() => set('goal', g.val)}>
                <div style={{ fontSize: 24, marginBottom: 4 }}>{g.icon}</div>{g.label}
              </OptionCard>
            ))}
          </div>
          <h3 style={sh}>Activity level</h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 24 }}>
            {activities.map(a => (
              <div key={a.val} onClick={() => set('activity', a.val)} style={{
                border: profile.activity===a.val ? '2px solid #534AB7' : '1px solid #e5e7eb',
                background: profile.activity===a.val ? '#EEEDFE' : '#fff',
                borderRadius: 12, padding: '12px 14px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 10
              }}>
                <div>
                  <div style={{ fontSize: 14, fontWeight: 600, color: profile.activity===a.val ? '#3C3489' : '#222' }}>{a.label}</div>
                  <div style={{ fontSize: 12, color: '#888' }}>{a.sub}</div>
                </div>
              </div>
            ))}
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            <button style={btnS} onClick={() => setStep(1)}>← Back</button>
            <button style={btnP} onClick={() => setStep(3)}>Continue →</button>
          </div>
        </>}

        {/* Step 3: Diet */}
        {step === 3 && <>
          <h3 style={sh}>Diet preference</h3>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 16 }}>
            {diets.map(d => (
              <OptionCard key={d.val} selected={profile.diet===d.val} onClick={() => set('diet', d.val)}>
                <div style={{ fontSize: 24, marginBottom: 4 }}>{d.icon}</div>{d.label}
              </OptionCard>
            ))}
          </div>
          <label style={lbl}>Allergies / restrictions</label>
          <input style={{ ...inp, marginBottom: 24 }} placeholder="e.g. nuts, dairy, gluten..." value={profile.allergies} onChange={e => set('allergies', e.target.value)} />
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            <button style={btnS} onClick={() => setStep(2)}>← Back</button>
            <button style={btnP} onClick={onDone}>Let's go! 🚀</button>
          </div>
        </>}
      </div>
    </div>
  )
}

const sh  = { fontSize: 15, fontWeight: 600, marginBottom: 10, color: '#1a1a2e' }
const lbl = { fontSize: 13, color: '#666', display: 'block', marginBottom: 4 }
const inp = { width: '100%', padding: '10px 12px', border: '1px solid #e5e7eb', borderRadius: 10, fontSize: 14, outline: 'none', color: '#222', marginBottom: 0 }
const btnP = { width: '100%', padding: 13, background: '#534AB7', color: '#fff', border: 'none', borderRadius: 10, fontSize: 15, fontWeight: 600, cursor: 'pointer' }
const btnS = { width: '100%', padding: 13, background: '#f5f5f5', color: '#555', border: 'none', borderRadius: 10, fontSize: 15, fontWeight: 500, cursor: 'pointer' }
