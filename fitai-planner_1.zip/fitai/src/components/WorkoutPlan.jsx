import { useState } from 'react'
import { callClaude, PlanScreen } from './DietPlan.jsx'

export default function WorkoutPlan({ profile }) {
  const [extra, setExtra]     = useState('')
  const [result, setResult]   = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError]     = useState('')

  const generate = async () => {
    setLoading(true); setError(''); setResult('')
    try {
      const system = `You are a certified personal trainer. Create safe, effective, personalized workout plans.
Format with clear sections: Day, Workout name, Exercises with sets/reps/rest.
Include warm-up and cool-down. Be motivating and specific.`
      const user = `Create a weekly workout plan.
Profile: ${profile.age}yr, ${profile.gender}, ${profile.weight}kg, ${profile.height}cm.
Goal: ${profile.goal.replace('-',' ')} | Activity level: ${profile.activity}.
${extra ? 'Extra notes: '+extra : ''}
Make it 4–5 days/week with rest days. Include estimated duration per session.`
      const text = await callClaude(system, user)
      setResult(text)
    } catch(e) {
      setError('Could not connect to Claude AI. Check your API key in the .env file.')
    }
    setLoading(false)
  }

  return <PlanScreen
    icon="🏋️" title="AI Workout Plan" color="#1D9E75" bgColor="#E1F5EE"
    placeholder="e.g. I have dumbbells, focus on abs, 30-min sessions, no running..."
    extra={extra} setExtra={setExtra}
    generate={generate} loading={loading} result={result} error={error}
    btnLabel="Generate my workout plan"
  />
}
