export default function Dashboard({ profile, go }) {
  const name = profile.name || 'there'
  const hour = new Date().getHours()
  const greeting = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening'

  const stats = [
    { val: '1,850', label: 'Calories', unit: 'kcal' },
    { val: '7,240', label: 'Steps', unit: '' },
    { val: '1.8L',  label: 'Water', unit: '' },
    { val: '32m',   label: 'Workout', unit: '' },
  ]

  const goals = [
    { label: 'Calories', cur: 1850, max: 2100, color: '#534AB7' },
    { label: 'Steps',    cur: 7240, max: 10000, color: '#1D9E75' },
    { label: 'Water',    cur: 1.8,  max: 2.5,  color: '#EF9F27' },
  ]

  return (
    <div>
      {/* Header */}
      <div style={{ background: 'linear-gradient(135deg,#534AB7,#1D9E75)', padding: '1.5rem 1.25rem 1.25rem', color: '#fff' }}>
        <h2 style={{ fontSize: 20, fontWeight: 600 }}>{greeting}, {name}! 👋</h2>
        <p style={{ fontSize: 13, opacity: 0.85, marginTop: 3 }}>You're on track — keep going!</p>
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 6, background: 'rgba(255,255,255,0.2)', borderRadius: 20, padding: '4px 12px', fontSize: 13, marginTop: 10 }}>
          🔥 5-day streak
        </div>
      </div>

      <div style={{ padding: '1rem 1.25rem' }}>
        {/* Stats */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 20 }}>
          {stats.map(s => (
            <div key={s.label} style={{ background: '#f8f7ff', borderRadius: 12, padding: '1rem', textAlign: 'center' }}>
              <div style={{ fontSize: 22, fontWeight: 700, color: '#534AB7' }}>{s.val}</div>
              <div style={{ fontSize: 12, color: '#888', marginTop: 2 }}>{s.label}</div>
            </div>
          ))}
        </div>

        {/* Goals */}
        <h3 style={sh}>Today's goals</h3>
        {goals.map(g => (
          <div key={g.label} style={{ marginBottom: 14 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, marginBottom: 5 }}>
              <span style={{ fontWeight: 500 }}>{g.label}</span>
              <span style={{ color: '#888' }}>{g.cur} / {g.max}</span>
            </div>
            <div style={{ background: '#f0f0f0', borderRadius: 6, height: 8, overflow: 'hidden' }}>
              <div style={{ height: '100%', borderRadius: 6, background: g.color, width: `${Math.min(100, Math.round(g.cur/g.max*100))}%`, transition: 'width 0.6s' }} />
            </div>
          </div>
        ))}

        {/* Quick actions */}
        <h3 style={{ ...sh, marginTop: 20 }}>Quick actions</h3>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 10 }}>
          {[
            { icon: '🥗', title: 'Diet plan', sub: 'AI meal plan', screen: 'diet' },
            { icon: '🏋️', title: 'Workout', sub: 'AI routine', screen: 'workout' },
            { icon: '📊', title: 'Progress', sub: 'This week', screen: 'progress' },
            { icon: '🏆', title: 'Leaderboard', sub: 'Your rank', screen: 'leaderboard' },
          ].map(a => (
            <div key={a.screen} onClick={() => go(a.screen)} style={{ border: '1px solid #ede9fe', borderRadius: 14, padding: '1rem', cursor: 'pointer', background: '#fff' }}>
              <div style={{ fontSize: 26, marginBottom: 6 }}>{a.icon}</div>
              <div style={{ fontSize: 14, fontWeight: 600, color: '#1a1a2e' }}>{a.title}</div>
              <div style={{ fontSize: 12, color: '#888', marginTop: 2 }}>{a.sub}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

const sh = { fontSize: 15, fontWeight: 600, color: '#1a1a2e', marginBottom: 12 }
