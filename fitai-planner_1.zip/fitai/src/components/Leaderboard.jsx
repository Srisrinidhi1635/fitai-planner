const players = [
  { init: 'SR', name: 'Sara',   pts: 1840, bg: '#E1F5EE', tc: '#0F6E56' },
  { init: 'MK', name: 'Mike',   pts: 1620, bg: '#FAEEDA', tc: '#633806' },
  { init: 'JD', name: 'Jordan', pts: 1480, bg: '#FCEBEB', tc: '#A32D2D' },
  { init: 'PR', name: 'Priya',  pts: 1320, bg: '#EAF3DE', tc: '#3B6D11' },
  { init: 'TN', name: 'Tom',    pts: 1100, bg: '#E6F1FB', tc: '#185FA5' },
]

export default function Leaderboard({ profile }) {
  const me = { init: (profile.name || 'ME').slice(0,2).toUpperCase(), name: profile.name || 'You', pts: 2150 }

  return (
    <div>
      <div style={{ padding: '1.25rem', borderBottom: '1px solid #f0f0f0' }}>
        <h2 style={{ fontSize: 20, fontWeight: 600 }}>🏆 Leaderboard</h2>
        <p style={{ fontSize: 13, color: '#888', marginTop: 3 }}>Weekly rankings</p>
      </div>

      <div style={{ padding: '1rem 1.25rem' }}>
        {/* Podium */}
        <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'center', gap: 12, margin: '1rem 0 1.5rem' }}>
          {/* 2nd */}
          <Podium init={players[0].init} name={players[0].name} pts={players[0].pts} height={64} medal="🥈" bg={players[0].bg} tc={players[0].tc} size={44} />
          {/* 1st - you */}
          <Podium init={me.init} name={me.name} pts={me.pts} height={90} medal="🥇" bg="#EEEDFE" tc="#3C3489" size={52} highlight />
          {/* 3rd */}
          <Podium init={players[1].init} name={players[1].name} pts={players[1].pts} height={48} medal="🥉" bg={players[1].bg} tc={players[1].tc} size={44} />
        </div>

        {/* Rest of list */}
        <h3 style={sh}>All participants</h3>
        {players.slice(2).map((p, i) => (
          <div key={p.name} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 14px', borderRadius: 12, marginBottom: 8, background: '#f9f9f9' }}>
            <span style={{ fontSize: 14, fontWeight: 600, color: '#888', width: 20 }}>{i + 4}</span>
            <div style={{ width: 36, height: 36, borderRadius: '50%', background: p.bg, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 14, fontWeight: 700, color: p.tc }}>{p.init}</div>
            <span style={{ flex: 1, fontSize: 14, fontWeight: 500 }}>{p.name}</span>
            <span style={{ fontSize: 14, fontWeight: 700, color: '#534AB7' }}>{p.pts.toLocaleString()} pts</span>
          </div>
        ))}
      </div>
    </div>
  )
}

function Podium({ init, name, pts, height, medal, bg, tc, size, highlight }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4 }}>
      <div style={{ width: size, height: size, borderRadius: '50%', background: bg, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: size > 44 ? 18 : 15, fontWeight: 700, color: tc, border: highlight ? '2px solid #534AB7' : 'none' }}>{init}</div>
      <span style={{ fontSize: 12, fontWeight: 600, color: '#1a1a2e' }}>{name}</span>
      <span style={{ fontSize: 11, color: '#888' }}>{pts.toLocaleString()}</span>
      <div style={{ width: 52, height, borderRadius: '4px 4px 0 0', background: highlight ? '#7F77DD' : '#e5e7eb' }} />
      <span style={{ fontSize: highlight ? 22 : 18 }}>{medal}</span>
    </div>
  )
}

const sh = { fontSize: 15, fontWeight: 600, color: '#1a1a2e', marginBottom: 10 }
