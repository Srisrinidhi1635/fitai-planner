import { useState } from 'react'

export default function Login({ onLogin }) {
  const [email, setEmail] = useState('')
  const [pass, setPass] = useState('')

  return (
    <div style={{ minHeight: '100vh', background: 'linear-gradient(160deg,#EEEDFE 0%,#E1F5EE 100%)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '2rem' }}>
      <div style={{ background: '#fff', borderRadius: 20, padding: '2rem 1.5rem', width: '100%', maxWidth: 360, boxShadow: '0 4px 24px rgba(83,74,183,0.10)' }}>
        <div style={{ width: 64, height: 64, borderRadius: '50%', background: '#EEEDFE', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 1rem', fontSize: 32 }}>🌿</div>
        <h1 style={{ fontSize: 22, fontWeight: 600, textAlign: 'center', color: '#1a1a2e', marginBottom: 4 }}>FitAI Planner</h1>
        <p style={{ fontSize: 14, color: '#888', textAlign: 'center', marginBottom: 24 }}>Your AI-powered diet & workout companion</p>

        <label style={lbl}>Email</label>
        <input style={inp} type="email" placeholder="you@example.com" value={email} onChange={e => setEmail(e.target.value)} />

        <label style={{ ...lbl, marginTop: 12 }}>Password</label>
        <input style={inp} type="password" placeholder="••••••••" value={pass} onChange={e => setPass(e.target.value)} />

        <button style={btn} onClick={onLogin}>Sign in</button>
        <button style={{ background: 'none', border: 'none', color: '#534AB7', fontSize: 14, cursor: 'pointer', width: '100%', marginTop: 12, textAlign: 'center' }} onClick={onLogin}>
          New here? Set up your profile →
        </button>
      </div>
    </div>
  )
}

const lbl = { fontSize: 13, color: '#666', display: 'block', marginBottom: 4 }
const inp = { width: '100%', padding: '10px 12px', border: '1px solid #e5e7eb', borderRadius: 10, fontSize: 15, outline: 'none', color: '#222' }
const btn = { width: '100%', padding: 13, background: '#534AB7', color: '#fff', border: 'none', borderRadius: 10, fontSize: 15, fontWeight: 600, cursor: 'pointer', marginTop: 20 }
